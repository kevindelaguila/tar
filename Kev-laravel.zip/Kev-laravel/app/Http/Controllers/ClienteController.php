<?php

namespace App\Http\Controllers;

use App\Models\Cliente;
use Illuminate\Http\Request;

class ClienteController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $clientes = Cliente::all();
        return response()->json($clientes, 200);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $rules = [
            'Nombre' => 'max:20|required',
            'Apellido' => 'required',
            'Nit' => 'required'
        ];
        $messages = [
            'required' => 'El campo :attribute es obligatorio.',
            'max' => 'Ha sobre pasado la longitud máxima del campo :attribute'
        ];
        $validator = Validator::make($request->all(), $rules, $messages);
        if ($validator->fails()) {
            return response()->json([
                'message' => "Información incompleta o inválida -> ".$validator->messages()->first()
            ], 400);
        }
        $clientes = Cliente::create($request->all());
        return response()->json([
            'message' => "Cliente guardado satisfactoriamente!",
            'cliente' => $clientes
        ], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $clientes = Cliente::find($id);
        return response()->json($clientes, 200);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Cliente $clientes)
    {
        $clientes->update($request->all());

        return response()->json([
            'message' => "Cliente actualizado satisfactoriamente!",
            'cliente' => $clientes
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Cliente  $clientes
     * @return \Illuminate\Http\Response
     */
    public function destroy(Cliente $clientes)
    {
        $clientes->delete();

        return response()->json([
            'message' => "Cliente eliminado satisfactoriamente!",
        ], 200);
    }
}