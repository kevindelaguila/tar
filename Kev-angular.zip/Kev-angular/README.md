Project based from https://www.tutsmake.com/angular-13-crud-example-with-web-api/

Install dependencies

npm install

For API use https://github.com/melgust/laravel-9-jwt