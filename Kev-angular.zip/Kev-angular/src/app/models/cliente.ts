export class Cliente {
  public Nombre: string;
  public Apellido: string;
  public Nit: string;
}
