export class Product {
    public product_id: number;
    public name: string;
    public description: string;
    public reference: string;
    public price: number;
    public status_id: number;
    public created_at: Date;
    public updated_at: Date;

}
